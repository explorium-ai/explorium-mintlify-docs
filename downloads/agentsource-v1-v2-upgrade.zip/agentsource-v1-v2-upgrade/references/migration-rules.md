# AgentSource v1 to v2 Migration Rules

Source: <https://developers.explorium.ai/v2/migration-from-v1> (retrieved 2026-09-09).
AgentSource v2 reached general availability on 2026-09-02. Re-check the source when network access is
available if this reference is stale.

## Endpoint Mapping

| v1 | v2 | Migration behavior |
| --- | --- | --- |
| `/v1/businesses/{enrichment}/bulk_enrich` | `/v2/businesses/{enrichment}/enrich` or `/job` | Remove the bulk route. Use `/enrich` for immediate results; use `/job` for async runs. |
| `/v1/prospects/contacts_information/bulk_enrich` | `/v2/prospects/contact_information/enrich` or `/job` | Rename the path and choose sync or async. |
| `/v1/businesses/research/bulk_enrich` | `/v2/businesses/research/enrich` or `/job` | Remove the bulk route and choose sync or async. |
| `/v1/prospects/research/bulk_enrich` | `/v2/prospects/research/enrich` or `/job` | Remove the bulk route and choose sync or async. |
| Business or prospect autocomplete route | `/v2/autocomplete` | Replace entity-specific autocomplete routes with the consolidated route. |
| `/v1/businesses`, `/match`, `/stats` | Equivalent `/v2` route | Path-only change, subject to v2 request validation. |
| `/v1/prospects`, `/match`, `/stats` | Equivalent `/v2` route | Path-only change, subject to v2 request validation. |
| v1 credits | Equivalent `/v2` route | Path-only change. |
| `/v1/{entity}/events` | Equivalent `/v2` route | Update corrected event payload fields. |
| `/v1/{entity}/events/enrollments` | Equivalent `/v2` route | Bind each enrollment to a `webhook_id`. |
| `/v1/webhooks` | `/v2/webhooks` | Structural migration; see Webhooks. |

Do not globally replace every `/v1` string in a repository. Limit replacements to AgentSource endpoints.
Other services can independently retain v1 routes.

## Sync and Async

- Map an existing call that returns enrichment data immediately to `/enrich` by default.
- Map large or explicitly asynchronous runs to `/job`.
- Limit async input to 10,000 records and execution to the documented 24-hour job window.
- Add job creation response handling, status polling, terminal failure handling, timeout behavior, and
  result retrieval when moving to `/job`.
- Preserve one-ID versus list payload behavior intentionally. The same endpoint accepts either form.

## Request Changes

### Contact availability

Replace prospect fetch and stats filters as follows:

| v1 intent | v2 filter |
| --- | --- |
| `has_email: true` | `has_contact_details: "email"` |
| `has_phone_number: true` | `has_contact_details: "phone"` |
| Both old filters true | `has_contact_details: "email_and_phone"` |
| At least one contact method | `has_contact_details: "email_or_phone"` |

Some clients wrap filter values as `{ value, negate }`. Preserve the integration's established filter
envelope while replacing the semantic value. Do not infer a positive v2 filter from a false, null, or
negated legacy value without checking behavior.

### Fetch bodies

- Remove the `size` pagination parameter from AgentSource fetch requests.
- Keep supported cursor and page-size behavior according to the v2 endpoint schema. If the v1 builder
  forwarded `next_cursor` through an input spread, include it explicitly in the v2 allowlist and test a
  non-empty cursor. Removing `size` must not silently disable subsequent-page requests.
- Set `include_operating_locations` explicitly when the integration relied on the v1 default. Infer the
  intended boolean from existing tests or product behavior; do not guess.
- Remove client-only routing, execution, and UI fields from the wire body. v2 request models can reject
  unknown keys even when v1 accepted them.

## Path and Field Renames

| v1 | v2 | Scope |
| --- | --- | --- |
| `contacts_information` | `contact_information` | Prospect endpoint path |
| `professions_email` | `professional_email` | Prospect contact response |
| `employee_joined_company` | `executive_joined_company` | Event filters, enrollments, responses, and webhook handlers |
| `founding_stage` | `funding_stage` | `new_funding_round` event payload |
| `founding_date` | `funding_date` | `new_funding_round` event payload |
| `money_spend_on_website_technologies` | `money_spent_on_website_technologies` | Webstack response |
| `latest_funding_increase_in_percents` | `latest_funding_increase_percentage` | Funding and acquisition response |
| `time_took_in_seconds` | `time_taken_in_seconds` | `response_context` on every endpoint |

Update runtime reads, static types, validation schemas, transformations, snapshots, fixtures, tests,
examples, and docs. Avoid temporary dual-read aliases unless persisted data or an external response
contract concretely requires a migration window.

## Removed Response Fields

- Stop reading `entity_id`. Do not invent a replacement without the endpoint response schema.
- Stop reading `display_name` from business LinkedIn post responses.
- Stop reading address signals from `company_ratings_by_employees` responses.
- Stop reading or destructuring `emails` from sync or async `contact_information` responses. Depending
  on the downstream intent, use `professional_email`, `professional_email_status`, `mobile_phone`, or
  `phone_numbers` instead. Add an adjacent comment where the format permits it:
  `AgentSource v2 migration: emails array removed in v2; use professional_email, phone_numbers, or mobile_phone instead.`

Generic occurrences of `entity_id`, `display_name`, `emails`, or address fields outside these response
contexts are not sufficient evidence for removal. Trace the value to the AgentSource endpoint first.

In the migration summary, state: "`emails` field removed from `contact_information` response; update any
downstream logic that reads this field." List unresolved consumers with file and line references.

## Event Name Rename

Replace `employee_joined_company` with `executive_joined_company` on every v2 event surface:

- `filters.events.values` in business fetch and stats requests.
- `event_types` in enrollment create and update bodies.
- `output_events[].event_name` comparisons in fetch-event response handlers.
- Event-name comparisons in webhook push handlers, including switch and match cases.

Add an adjacent comment where the format permits it:
`AgentSource v2 migration: renamed from employee_joined_company in v2.` For JSON, generated files, or
other formats that cannot carry comments, record the location only in the migration summary. Report the
total replacement count and each file location, grouped by the four surfaces above.

## Webhooks

Treat webhooks as a data-model and lifecycle migration, not a path rename:

- v1 has one partner-level webhook and registration overwrites it.
- v2 supports multiple tenant-scoped webhooks identified by `webhook_id`.
- Register each destination, persist its `webhook_id` and secret, and bind event enrollments to that ID.
- Update create/list/delete or rotation flows, storage schema, tenant isolation, retries, and tests.
- The migrated legacy webhook can appear with `legacy: true`; handle it explicitly if listing webhooks.

## Completion Checklist

- No unexplained AgentSource `/v1` endpoints remain.
- No `/bulk_enrich` endpoints remain.
- Sync or async semantics are implemented, not merely renamed.
- Autocomplete uses `/v2/autocomplete`.
- Contact path, response fields, and event fields use v2 names.
- No `contact_information` response consumer reads or destructures the removed `emails` array; migration
  comments and the summary identify suitable replacement fields and unresolved downstream behavior.
- No `employee_joined_company` event names remain across fetch filters, stats filters, enrollment bodies,
  fetch-event response handlers, or webhook handlers; each rename is commented where permitted and
  counted with its location in the migration summary.
- Removed response fields are no longer consumed in affected contexts.
- Contact filters preserve email, phone, both, or either intent.
- Fetch requests omit `size` and unsupported client-only keys.
- `include_operating_locations` is explicit where old behavior depended on its default.
- Async input and polling behavior obey limits.
- Webhook registrations and enrollments use stored tenant-scoped `webhook_id` values.
- Tests and fixtures encode v2 request and response contracts.

# Validation Against Vibe Prospecting

## Compared Implementation

- Jira reference: PTB-2197.
- Merged PR: `#951`, merge commit `f4acf6d9`.
- Main migration commit: `e469e6cc`.
- Follow-up compatibility commit: `fcb37e5a`.
- Renamed response-field follow-up: `696f9ac4` from PTB-2278.
- Validation date: 2026-09-01.

The comparison used the completed VP migration as implementation evidence, not as a substitute for the
public migration contract. VP did not exercise every AgentSource feature.

## Rules Confirmed by VP

| Rule | VP evidence | Result |
| --- | --- | --- |
| `/v1` to `/v2` | Match, fetch, stats, and enrichment registries changed to v2. | Confirmed |
| Remove `/bulk_enrich` | Business and prospect enrichments changed to `/enrich`. | Confirmed for sync |
| Rename contact route | `contacts_information` changed to `contact_information`. | Confirmed |
| Consolidate autocomplete | Business and prospect autocomplete changed to `/v2/autocomplete`. | Confirmed |
| Contact filter migration | `has_email` and `has_phone_number` changed to `has_contact_details`. | Confirmed |
| Remove `size` | Fetch body stopped sending `size`. | Confirmed |
| Explicit operating locations | Business filters explicitly set `include_operating_locations`. | Confirmed |
| Rename professional email | Output schema changed to `professional_email`. | Confirmed |
| Correct response fields | Webstack, funding, and response-context schemas changed in PTB-2278. | Confirmed in follow-up |

## Additional Finding

VP v2 request validation rejects unknown fields. Its migration stopped spreading the complete MCP input
into fetch request bodies and instead allowlisted API fields. This removed values such as `entity_type`,
session and reasoning metadata, execution flags, and UI-only options from the wire. Apply the same audit
to every migrated integration even though the public guide highlights only `size`.

VP also removed a special `1000+` display cap and used `total_results` directly. Treat this as VP-specific
response behavior, not a universal migration rule without endpoint evidence.

## Compatibility Finding

The initial VP migration replaced the old contact filter inputs outright. A follow-up accepted
`has_email` and `has_phone_number` at VP's public tool boundary, translated them to
`has_contact_details`, and stripped the old keys before calling v2.

Do not reproduce this compatibility layer by default. Add it only when the integration has shipped
external callers that still send the old input. Prefer direct schema migration for private or fully
controlled codebases.

## Not Covered by VP

- `/job` async orchestration and the 10,000-record limit.
- Webhook registration, secret persistence, and enrollment binding.
- Event enrollment migration and `funding_stage` or `funding_date` event payloads.
- Removed `entity_id` reads.
- Removed business LinkedIn `display_name` reads.
- Removed employee-rating address signals.
- Research enrichment endpoints.

Treat these as unvalidated by the VP comparison. Follow the canonical migration guide and add targeted
tests when they exist in the codebase.

## Edge Cases

- A blind repository-wide `/v1` replacement would modify unrelated versioned services.
- A blind `/bulk_enrich` to `/enrich` replacement can silently convert an asynchronous workload to sync.
- `has_email` plus `has_phone_number` means both, not either.
- A generic `entity_id` or `display_name` occurrence is not necessarily an affected response read.
- Permissive output schemas can conceal stale field names by dropping or ignoring actual v2 data.
- Updating implementation without fixtures and snapshots leaves false confidence about response changes.

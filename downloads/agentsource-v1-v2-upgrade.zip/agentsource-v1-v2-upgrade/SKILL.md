---
name: agentsource-v1-v2-upgrade
description: This skill should be used when migrating Explorium AgentSource API integrations from v1 to v2, auditing code for deprecated AgentSource endpoints, fields, filters, pagination, autocomplete, events, or webhooks, or reviewing an AgentSource v1-to-v2 migration.
---

# AgentSource v1 to v2 Upgrade

Migrate an existing integration in place while preserving its behavior. Handle source code,
configuration, schemas, tests, examples, and documentation. Produce working v2 code, concise inline
migration comments where the file format permits them, and a final migration summary.

## Workflow

1. Read `references/migration-rules.md` before changing code. Read
   `references/vp-validation.md` when choosing transformations or reviewing edge cases.
2. Establish scope from the user-provided files, snippet, or repository. Inspect repository
   instructions and existing changes. Never overwrite unrelated work.
3. Run `python3 scripts/scan_v1.py <paths...>` from this skill directory, or invoke it with an
   absolute path, to inventory likely v1 patterns. Use `--format json` when structured output helps.
4. Search call sites, serializers, response schemas, tests, fixtures, examples, and docs for every
   finding. Do not treat a clean endpoint registry as a complete migration.
5. Classify each change as safe, behavior-dependent, or manual-review-only. Resolve behavior-dependent
   choices from code and tests. Ask one focused question only when choosing incorrectly would change
   external behavior, especially sync versus async or webhook ownership.
6. Apply the smallest complete migration. Update API request and response validation together with
   implementation code. Add a short adjacent comment beginning `AgentSource v2 migration:` for each
   non-obvious transformation. Remove `emails` reads from `contact_information` responses and point to
   `professional_email`, `professional_email_status`, `mobile_phone`, or `phone_numbers`. Rename every
   `employee_joined_company` event use to `executive_joined_company` across filters, enrollments,
   response handlers, and webhook handlers. Do not add comments to JSON or generated files.
7. Preserve immediate-result behavior with `/enrich`. Choose `/job` only when the integration already
   has asynchronous orchestration or explicitly requires large runs. Implement job polling, failure,
   timeout, and 10,000-input enforcement when choosing `/job`; a path replacement alone is incomplete.
8. Remove unsupported v1 wire fields instead of hiding them behind permissive schemas. When replacing
   an input spread with a v2 allowlist, preserve supported pagination fields, including `page_size` and
   `next_cursor`; add an exact request-body test proving cursor forwarding. Add temporary
   legacy-input translation only for a shipped public input contract; translate at the API boundary and
   never send deprecated keys to v2.
9. Update tests to assert endpoint paths, exact request bodies, renamed response fields, filter semantics,
   and absence of removed fields. Add webhook lifecycle or async-job tests when those flows are present.
10. Run the scanner again. Investigate every remaining blocker. Record contextual findings that are not
    AgentSource usage as ignored false positives; do not mutate unrelated APIs merely because they use
    `/v1` or a generic field name.
11. Run the repository's formatter, type checker, targeted tests, and broader checks appropriate to the
    changed surface.

## Output Contract

Return migrated code in the user's workspace or, for a snippet-only request, in the response. Include:

- Inline comments for non-obvious changes and manual follow-up points.
- Applied changes grouped by endpoints, requests, responses, and operational flows.
- A clear note that `emails` was removed from `contact_information`, including downstream logic that
  still needs an explicit replacement.
- The count and file locations of all `employee_joined_company` to `executive_joined_company` renames,
  grouped by fetch filters, event enrollments, response handlers, and webhook handlers.
- Manual-review items with file and line references.
- Verification commands and outcomes.
- Any scanner false positives intentionally left unchanged.

Do not claim completion while blocker findings remain unexplained. Do not claim webhook or async-job
migration success when only the endpoint string changed.

#!/usr/bin/env python3
"""Report likely AgentSource v1 migration patterns without modifying files."""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


SKIP_DIRS = {
    ".git",
    ".idea",
    ".next",
    ".venv",
    "build",
    "coverage",
    "dist",
    "node_modules",
    "target",
    "vendor",
    "agentsource-v1-v2-upgrade",
}

TEXT_SUFFIXES = {
    ".c",
    ".cc",
    ".conf",
    ".cpp",
    ".cs",
    ".go",
    ".graphql",
    ".h",
    ".hpp",
    ".html",
    ".java",
    ".js",
    ".json",
    ".jsonc",
    ".jsx",
    ".kt",
    ".md",
    ".mjs",
    ".php",
    ".py",
    ".rb",
    ".rs",
    ".sh",
    ".sql",
    ".swift",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".xml",
    ".yaml",
    ".yml",
}


@dataclass(frozen=True)
class Rule:
    rule_id: str
    severity: str
    pattern: re.Pattern[str]
    message: str


@dataclass(frozen=True)
class Finding:
    rule_id: str
    severity: str
    path: str
    line: int
    column: int
    match: str
    message: str


RULES = (
    Rule(
        "agentsource-v1-endpoint",
        "blocker",
        re.compile(
            r"(?<![A-Za-z0-9_])/?v1/(?:businesses|prospects|autocomplete|webhooks|credits)(?:\b|/)",
            re.I,
        ),
        "Migrate this AgentSource endpoint to its v2 equivalent; do not replace unrelated v1 APIs.",
    ),
    Rule(
        "bulk-enrich",
        "blocker",
        re.compile(r"/bulk_enrich\b"),
        "Choose /enrich for synchronous behavior or implement the complete /job lifecycle.",
    ),
    Rule(
        "contacts-path",
        "blocker",
        re.compile(r"\bcontacts_information\b"),
        "Rename the prospect endpoint segment to contact_information.",
    ),
    Rule(
        "professional-email-field",
        "blocker",
        re.compile(r"\bprofessions_email\b"),
        "Rename the response field to professional_email.",
    ),
    Rule(
        "removed-contact-emails-field",
        "review",
        re.compile(
            r"(?:\??\.emails\b|"
            r"\[\s*[\"']emails[\"']\s*\]|"
            r"\.get\s*\(\s*[\"']emails[\"']|"
            r"[,{]\s*emails\s*[,}:=]|"
            r"^\s*emails\s*[,}:=])"
        ),
        "Remove this read if it comes from a contact_information response; use professional_email, "
        "professional_email_status, mobile_phone, or phone_numbers instead.",
    ),
    Rule(
        "employee-joined-company-event",
        "blocker",
        re.compile(r"\bemployee_joined_company\b"),
        "Rename this event to executive_joined_company across filters, enrollments, responses, and webhooks.",
    ),
    Rule(
        "funding-stage-field",
        "blocker",
        re.compile(r"\bfounding_stage\b"),
        "Rename new_funding_round event payload reads to funding_stage.",
    ),
    Rule(
        "funding-date-field",
        "blocker",
        re.compile(r"\bfounding_date\b"),
        "Rename new_funding_round event payload reads to funding_date.",
    ),
    Rule(
        "webstack-spend-field",
        "blocker",
        re.compile(r"\bmoney_spend_on_website_technologies\b"),
        "Rename the webstack response field to money_spent_on_website_technologies.",
    ),
    Rule(
        "funding-percentage-field",
        "blocker",
        re.compile(r"\blatest_funding_increase_in_percents\b"),
        "Rename the response field to latest_funding_increase_percentage.",
    ),
    Rule(
        "response-time-field",
        "blocker",
        re.compile(r"\btime_took_in_seconds\b"),
        "Rename response_context field to time_taken_in_seconds.",
    ),
    Rule(
        "legacy-contact-filter",
        "blocker",
        re.compile(r"[\"']?(?:has_email|has_phone_number)[\"']?\s*[:=]"),
        "Replace with has_contact_details while preserving email, phone, both, or either semantics.",
    ),
    Rule(
        "size-parameter",
        "review",
        re.compile(r"[\"']?size[\"']?\s*[:=]"),
        "Remove only when this value is sent as AgentSource fetch pagination.",
    ),
    Rule(
        "entity-id-field",
        "review",
        re.compile(r"\bentity_id\b"),
        "Stop reading this field only when it comes from an affected AgentSource v2 response.",
    ),
    Rule(
        "linkedin-display-name",
        "review",
        re.compile(r"\bdisplay_name\b"),
        "Stop reading this field only in business LinkedIn post responses.",
    ),
    Rule(
        "employee-rating-address",
        "review",
        re.compile(r"company_ratings_by_employees"),
        "Audit this response handling for removed address signals.",
    ),
)


def iter_files(paths: Iterable[Path]) -> Iterable[Path]:
    seen: set[Path] = set()
    for path in paths:
        if path.is_file():
            candidates = (path,)
        elif path.is_dir():
            candidates = (
                candidate
                for candidate in path.rglob("*")
                if candidate.is_file() and not any(part in SKIP_DIRS for part in candidate.parts)
            )
        else:
            print(f"warning: path does not exist: {path}", file=sys.stderr)
            continue

        for candidate in candidates:
            resolved = candidate.resolve()
            if resolved in seen or candidate.suffix.lower() not in TEXT_SUFFIXES:
                continue
            seen.add(resolved)
            yield candidate


def migration_comment_start(line: str) -> int | None:
    marker = "AgentSource v2 migration:"
    quote: str | None = None
    escaped = False
    index = 0

    while index < len(line):
        character = line[index]
        if quote:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            index += 1
            continue

        if character in "'\"`":
            quote = character
            index += 1
            continue

        for token in ("//", "#", "--"):
            if line.startswith(token, index):
                comment = line[index + len(token) :].lstrip()
                return index if comment.startswith(marker) else None
        index += 1

    return None


def scan_file(path: Path) -> list[Finding]:
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as error:
        print(f"warning: cannot read {path}: {error}", file=sys.stderr)
        return []

    findings: list[Finding] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        migration_comment_index = migration_comment_start(line)
        for rule in RULES:
            for match in rule.pattern.finditer(line):
                if (
                    rule.rule_id == "employee-joined-company-event"
                    and migration_comment_index is not None
                    and match.start() > migration_comment_index
                ):
                    continue
                findings.append(
                    Finding(
                        rule_id=rule.rule_id,
                        severity=rule.severity,
                        path=str(path),
                        line=line_number,
                        column=match.start() + 1,
                        match=match.group(0),
                        message=rule.message,
                    )
                )
    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="*", default=["."], help="Files or directories to scan")
    parser.add_argument("--format", choices=("text", "json"), default="text")
    args = parser.parse_args()

    findings = [
        finding
        for path in iter_files(Path(raw_path) for raw_path in args.paths)
        for finding in scan_file(path)
    ]
    findings.sort(key=lambda finding: (finding.path, finding.line, finding.column, finding.rule_id))

    if args.format == "json":
        print(json.dumps([asdict(finding) for finding in findings], indent=2))
    else:
        for finding in findings:
            print(
                f"{finding.path}:{finding.line}:{finding.column}: "
                f"{finding.severity} [{finding.rule_id}] {finding.message} "
                f"(matched {finding.match!r})"
            )
        blockers = sum(finding.severity == "blocker" for finding in findings)
        reviews = len(findings) - blockers
        print(f"Found {blockers} blocker(s) and {reviews} review item(s).")

    return 1 if any(finding.severity == "blocker" for finding in findings) else 0


if __name__ == "__main__":
    raise SystemExit(main())

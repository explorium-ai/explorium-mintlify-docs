import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("scan_v1.py")
SPEC = importlib.util.spec_from_file_location("scan_v1", MODULE_PATH)
assert SPEC and SPEC.loader
scan_v1 = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = scan_v1
SPEC.loader.exec_module(scan_v1)


class ScanV1Test(unittest.TestCase):
    def scan(self, content: str):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "client.ts"
            path.write_text(content, encoding="utf-8")
            return scan_v1.scan_file(path)

    def test_reports_endpoint_bulk_route_and_renamed_field(self):
        findings = self.scan(
            'const endpoint = "/v1/prospects/contacts_information/bulk_enrich";\n'
            "return response.professions_email;\n"
        )

        self.assertEqual(
            {finding.rule_id for finding in findings},
            {
                "agentsource-v1-endpoint",
                "bulk-enrich",
                "contacts-path",
                "professional-email-field",
            },
        )

    def test_does_not_report_unrelated_v1_endpoint(self):
        findings = self.scan('const endpoint = "/v1/datasets";\n')

        self.assertEqual(findings, [])

    def test_marks_context_dependent_fields_for_review(self):
        findings = self.scan("const { entity_id, display_name } = item;\n")

        self.assertEqual({finding.severity for finding in findings}, {"review"})

    def test_reports_contact_information_email_reads_for_review(self):
        findings = self.scan(
            "const direct = response.data.emails;\n"
            "const optional = response.data?.emails;\n"
            'const indexed = result["emails"];\n'
            'const nested = response["contact_information"]["emails"];\n'
            'const mapped = result.get("emails");\n'
            'const defaulted = result.get("emails", []);\n'
            "const { emails } = contactInformation;\n"
            "const {\n  emails,\n} = contactInformation;\n"
        )

        self.assertEqual(
            [finding.rule_id for finding in findings],
            [
                "removed-contact-emails-field",
                "removed-contact-emails-field",
                "removed-contact-emails-field",
                "removed-contact-emails-field",
                "removed-contact-emails-field",
                "removed-contact-emails-field",
                "removed-contact-emails-field",
                "removed-contact-emails-field",
            ],
        )
        self.assertEqual({finding.severity for finding in findings}, {"review"})

    def test_does_not_report_unrelated_email_fields(self):
        findings = self.scan("const primary = user.email;\nconst list = newsletterEmails;\n")

        self.assertEqual(findings, [])

    def test_reports_deprecated_prospect_response_field_reads(self):
        findings = self.scan(
            "const department = prospect.job_department;\n"
            "const optionalDepartment = prospect?.job_department;\n"
            'const indexedDepartment = profile["job_department"];\n'
            'const seniority = profile.get("job_seniority_level");\n'
            "const { job_department, job_seniority_level } = prospect;\n"
        )

        self.assertEqual(
            [finding.rule_id for finding in findings],
            [
                "deprecated-job-department-response-field",
                "deprecated-job-department-response-field",
                "deprecated-job-department-response-field",
                "deprecated-job-seniority-response-field",
                "deprecated-job-department-response-field",
                "deprecated-job-seniority-response-field",
            ],
        )
        self.assertEqual({finding.severity for finding in findings}, {"review"})

    def test_reports_response_fixture_fields_for_review(self):
        findings = self.scan(
            "const prospect = { job_department: 'Sales', job_seniority_level: 'Director' };\n"
            'const fixture = { "job_department": "Sales", "job_seniority_level": "Director" };\n'
        )

        self.assertEqual(
            [finding.rule_id for finding in findings],
            [
                "deprecated-job-department-response-field",
                "deprecated-job-seniority-response-field",
                "deprecated-job-department-response-field",
                "deprecated-job-seniority-response-field",
            ],
        )
        self.assertEqual({finding.severity for finding in findings}, {"review"})

    def test_reports_request_filters_as_review_items_without_rewrite_instruction(self):
        findings = self.scan(
            "const direct = filters.job_department;\n"
            "const optional = request.filters?.job_seniority_level;\n"
            'const request = { filters: { job_department: ["Sales"] } };\n'
        )

        self.assertEqual(len(findings), 3)
        self.assertEqual({finding.severity for finding in findings}, {"review"})
        self.assertTrue(all("filter" in finding.message for finding in findings))

    def test_reports_employee_joined_company_on_every_event_surface(self):
        findings = self.scan(
            'const filters = { events: { values: ["employee_joined_company"] } };\n'
            'const enrollment = { event_types: ["employee_joined_company"] };\n'
            'if (event.event_name === "employee_joined_company") handle(event);\n'
            'case "employee_joined_company": notify(event);\n'
        )

        self.assertEqual(
            [finding.rule_id for finding in findings],
            ["employee-joined-company-event"] * 4,
        )
        self.assertEqual({finding.severity for finding in findings}, {"blocker"})

    def test_ignores_employee_joined_company_in_migration_comment(self):
        findings = self.scan(
            "// AgentSource v2 migration: renamed from employee_joined_company in v2.\n"
            'const eventName = "executive_joined_company";\n'
        )

        self.assertEqual(findings, [])

    def test_reports_legacy_event_before_inline_migration_comment(self):
        findings = self.scan(
            'const eventName = "employee_joined_company"; '
            "// AgentSource v2 migration: renamed from employee_joined_company in v2.\n"
        )

        self.assertEqual(
            [finding.rule_id for finding in findings],
            ["employee-joined-company-event"],
        )

    def test_reports_legacy_event_after_marker_text_in_string(self):
        findings = self.scan(
            'const note = "AgentSource v2 migration:"; '
            'const eventName = "employee_joined_company";\n'
        )

        self.assertEqual(
            [finding.rule_id for finding in findings],
            ["employee-joined-company-event"],
        )


if __name__ == "__main__":
    unittest.main()
